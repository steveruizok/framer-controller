import { Override } from "framer"
import { FormController } from "../../../../lib"

const controller = new FormController({
	name: {
		defaultValue: null,
		required: true,
		validation: v => v.includes(" "),
		errorText: v => "Please enter a first and last name.",
	},
	location: {
		defaultValue: null,
		required: false,
		validation: v => v.length > 3,
		errorText: v => "Please enter a first and last name.",
	},
	email: {
		defaultValue: null,
		required: true,
	},
})

export const NameInput: Override = () => {
	console.log(controller.data.name)
	return {
		onValueChange: value => controller.setValue("name", value),
	}
}

export const NameContainer: Override = () => ({
	$errorText: controller.data.name.errorText,
})

export const LocationInput: Override = () => ({
	value: controller.data.location.value,
	onChange: value => controller.setValue("location", value),
})

export const LocationContainer: Override = () => ({
	$errorText: controller.data.location.errorText,
})
