import { Override } from "framer"
import { FormController } from "../../../../lib"

const controller = new FormController({
    name: {
        defaultValue: null,
        required: true,
        validation: v => v.includes(" "),
        errorText: v => "Please enter a first and last name.",
    },
    location: {
        defaultValue: null,
        required: false,
    },
    state: {
        defaultValue: null,
        required: false,
        hidden: ({ location }) => !location.includes("USA"),
    },
    email: {
        defaultValue: null,
        required: true,
    },
})

export const NameInput: Override = () => ({
    value: controller.data.name.value,
    onChange: value => controller.data.setValue("name", value),
})

export const NameContainer: Override = () => ({
    test_prop: "hi",
})

export const LocationInput: Override = () => ({
    value: controller.data.location.value,
    onChange: value => controller.data.setValue("location", value),
})

export const LocationContainer: Override = () => ({
    $errorText: controller.data.location.errorText,
})
