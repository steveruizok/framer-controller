// WARNING: this file is auto generated, any changes will be lost
import { createDesignComponent, CanvasStore } from "framer"
const canvas = CanvasStore.shared(); // CANVAS_DATA;
export const Diviider = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string}>(canvas, "id_F2O1VQPTE", {}, 272,30);
export const NameField = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string,$label?:string,$errorText?:string}>(canvas, "id_QHJtogUk_", {$label:"string",$errorText:"string"}, 335,96);
export const OneValiue = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string,$label?:string,$value?:string}>(canvas, "id_y14M1Wbw9", {$label:"string",$value:"string"}, 335,56);
export const SelectField = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string,$label?:string,$errorText?:string}>(canvas, "id_Y_nQrmw0N", {$label:"string",$errorText:"string"}, 335,104);
export const TwoValues = createDesignComponent<{parentSize?:{width:number|string,height:number|string},width?:number|string,height?:number|string,$label?:string,$value?:string}>(canvas, "id_n1CUqkg8F", {$label:"string",$value:"string"}, 335,56);
