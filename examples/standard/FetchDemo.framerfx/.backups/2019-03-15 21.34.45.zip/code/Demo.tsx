import { Override } from "framer"
import { FetchController } from "../../../../lib"

const controller = new FetchController()

// Name

export const NameContainer: Override = () => ({
	$label: controller.data,
	$value: controller.data.name.errorText,
})

// Button

export const FetchButton: Override = () => ({
	disabled: !controller.refresh,
})
