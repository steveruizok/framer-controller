import { Override } from "framer"
import { FetchController } from "../../../../lib"

const controller = new FetchController({
	url: "https://randomuser.me/api/",
	parse: data => data.results[0],
})

// Name

export const NameContainer: Override = () => {
	console.log(controller.data)
	return {
		$label: "Name",
		$value: "ok",
	}
}

// Button

export const FetchButton: Override = () => ({
	disabled: !controller.refresh,
})
