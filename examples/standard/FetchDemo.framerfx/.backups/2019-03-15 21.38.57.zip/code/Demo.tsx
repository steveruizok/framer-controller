import { Override } from "framer"
import { FetchController } from "../../../../lib"

const controller = new FetchController({
	url: "https://randomuser.me/api/'",
})

// Name

export const NameContainer: Override = () => ({
	$label: "Name",
	$value: controller.data.results[0].name,
})

// Button

export const FetchButton: Override = () => ({
	disabled: !controller.refresh,
})
