import { Override } from "framer"
import { FetchController } from "../../../../lib"

const controller = new FetchController({
	url: "https://randomuser.me/api/",
	parse: data => data.results[0],
})

// Name

export const NameContainer: Override = () => ({
	$value:
		controller.data.name &&
		`${controller.data.name.first} ${controller.data.name.last}`,
})

export const AgeContainer: Override = () => ({
	$value:
		controller.data.name &&
		`${controller.data.name.first} ${controller.data.name.last}`,
})

// Button

export const FetchButton: Override = () => ({
	disabled: !controller.refresh,
})
