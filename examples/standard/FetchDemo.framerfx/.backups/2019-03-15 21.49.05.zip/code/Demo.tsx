import { Override } from "framer"
import { FetchController } from "../../../../lib"

const controller = new FetchController({
	url: "https://randomuser.me/api/",
	parse: data => data.results[0],
})

// Name

export const NameContainer: Override = () => ({
	$value:
		controller.data.name &&
		`${controller.data.name.first} ${controller.data.name.last}`,
})

export const AgeContainer: Override = () => ({
	$value1:
		controller.data.dob &&
		Date.parse(controller.data.dob.date).toLocaleString(),
	$value2: controller.data.dob && `Aged ${controller.data.dob.age}`,
})

// Button

export const FetchButton: Override = () => ({
	disabled: !controller.refresh,
})
