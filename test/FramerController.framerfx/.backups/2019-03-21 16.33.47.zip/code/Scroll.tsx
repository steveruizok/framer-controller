import { Override } from "framer"
import { ScrollController } from "../../../lib"

const controller = new ScrollController({
	useMarkers: true,
})

export const Scroll: Override = props => {
	controller.connect(props)
	return {
		contentOffsetY: -controller.scrollY,
		contentOffsetX: -controller.scrollX,
		onMove: controller.handleScroll,
		onTapStart: controller.stopAnimation,
	}
}

export const ScrollToButton: Override = props => {
	console.log(controller.progress)
	return {
		onClick() {
			controller.scrollToPosition({ x: 150, y: 500 })
		},
	}
}

export const ScrollToMarkerButton: Override = props => {
	return {
		onClick() {
			controller.scrollToMarker("id_GgNM8lDZQ", ["top", "left"], 32)
		},
	}
}

export const ScrollBox: Override = props => {
	const marker = controller.markers[props.id]
	if (!marker) return

	return {
		$clip_y: marker.clip.y,
		$clip_x: marker.clip.x,
		$visible: marker.visible.toString(),
		$intersect_x: marker.intersect.x.toFixed(5),
		$intersect_y: marker.intersect.y.toFixed(5),
		$offset_top: marker.offset.top.toFixed(5),
		$offset_right: marker.offset.right.toFixed(5),
		$offset_bottom: marker.offset.bottom.toFixed(5),
		$offset_left: marker.offset.left.toFixed(5),
		$absolute_top: marker.absolute.top.toFixed(5),
		$absolute_right: marker.absolute.right.toFixed(5),
		$absolute_bottom: marker.absolute.bottom.toFixed(5),
		$absolute_left: marker.absolute.left.toFixed(5),
	}
}

export const ControllerState: Override = () => ({
	$progress_x: controller.progress.x.toFixed(5),
	$progress_y: controller.progress.y.toFixed(5),
	$direction_x: controller.direction.x,
	$direction_y: controller.direction.y,
})
