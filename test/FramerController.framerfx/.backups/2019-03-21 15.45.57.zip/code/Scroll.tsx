import { Override } from "framer"
import { ScrollController } from "../../../lib"

const controller = new ScrollController({
	useMarkers: true,
})

export const Scroll: Override = props => {
	controller.connect(props)
	return {
		contentOffsetY: -controller.scrollY,
		onMove: controller.handleScroll,
	}
}

export const ScrollToButton: Override = props => {
	return {
		onClick() {
			controller.scrollToPosition({ x: 0, y: 500 })
		},
	}
}

export const ScrollToMarkerButton: Override = props => {
	return {
		onClick() {
			controller.scrollToMarker("id_c5I0hZwpJ", "top", 32)
		},
	}
}

export const ScrollBox: Override = props => {
	const marker = controller.markers[props.id]
	if (!marker) return

	return {
		$clip_y: marker.clip.y,
		$clip_x: marker.clip.x,
		$visible: marker.visible.toString(),
		$direction_x: controller.direction.x,
		$direction_y: controller.direction.y,
		$intersect_x: marker.intersect.x.toString(),
		$intersect_y: marker.intersect.y.toString(),
		$offset_top: marker.offset.top,
		$offset_right: marker.offset.right,
		$offset_bottom: marker.offset.bottom,
		$offset_left: marker.offset.left,
		$absolute_top: marker.absolute.top,
		$absolute_right: marker.absolute.right,
		$absolute_bottom: marker.absolute.bottom,
		$absolute_left: marker.absolute.left,
	}
}
