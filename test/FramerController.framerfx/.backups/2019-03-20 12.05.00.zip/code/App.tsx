import Controller from '../../../lib'
import { Data, animate, Override, Animatable } from 'framer'

const controller = new Controller({
	left: 0,
})

export const Animated: Override = () => {
	return {
		left: controller.state.left,
		onTap() {
			controller.animate({
				left: 200,
			})
		},
	}
}

export const Label: Override = () => {
	$value: controller.state.left
}
