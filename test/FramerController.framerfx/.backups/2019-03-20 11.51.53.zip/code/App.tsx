import Controller from '../../../lib'
import { Data, animate, Override, Animatable } from 'framer'

const controller = new Controller({
	left: 0,
})
export const Scale: Override = () => {
	return {
		left: controller.state.left,
		onTap() {
			controller.animate({
				left: 200,
			})
		},
	}
}
